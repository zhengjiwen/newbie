#!/usr/bin/env python
# -*- coding: utf-8 -*-
# Pw @ 2015-12-28 22:23:11
# Description:
from conf import setting
import json
import pickle
from modules import monitor
from modules import ret
import redis
import time

#主函数
class handle(object):
	def __init__(self):
		host_id=setting.id_host
		self.redis=monitor.RedisHelper(setting.redis_ip,setting.redis_channel)
		self.sub=self.redis.subscribe()
		self.rabbit=monitor.Rabbitmq(setting.rabbit_ip,setting.rabbit_channel)
		self.cmd=ret.cmd(host_id)

	def go(self):
		msg=self.sub.parse_response()[2]
		msg=pickle.loads(msg)
		for i in msg:
			func=getattr(self.cmd,i)
			ret_dict=func()
			ret_dict=json.dumps(ret_dict)
			self.rabbit.send_msg(ret_dict)
			time.sleep(0.1)
		self.go()

