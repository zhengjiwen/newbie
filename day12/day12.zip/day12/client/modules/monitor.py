#!/usr/bin/env python
# -*- coding: utf-8 -*-
# Pw @ 2015-12-29 12:40:04
# Description:
import redis
import pika

#you know
class RedisHelper:
	def __init__(self,ip,chan):
		self.__conn = redis.Redis(host=ip)
		self.chan_sub = chan

	def subscribe(self):
		pub = self.__conn.pubsub()
		pub.subscribe(self.chan_sub)
		pub.parse_response()
		return pub


class Rabbitmq:
		
	def __init__(self,ip,chan):
		connection = pika.BlockingConnection(pika.ConnectionParameters(host=ip))
		self.channel = connection.channel()
		self.chan = chan
		self.channel.queue_declare(queue=self.chan)
	
	def send_msg(self,msg):
		return self.channel.basic_publish(exchange='',routing_key=self.chan,body=msg)
