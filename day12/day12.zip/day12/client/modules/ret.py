#!/usr/bin/env python
# -*- coding: utf-8 -*-
# Pw @ 2015-12-30 08:43:53
# Description:

import os
import subprocess
import pickle
import json

#模板
class cmd(object):

	def __init__(self,host_id):
		self.host_id=host_id

	def disk(self):
		subp=subprocess.Popen('df -h',shell=True,stdout=subprocess.PIPE)
		ret=subp.stdout.readlines()[1].split()
		disk_dict = {}
		disk_dict['sum']=ret[1]
		disk_dict['use']=ret[2]
		disk_dict['free']=ret[3]
		disk_dict['pct']=ret[4][:-1]
		disk_dict['host_id']=self.host_id
		disk_dict['type']='disk'
		ret_dict=json.dumps(disk_dict)
		return ret_dict

	def mem(self):
		subp=subprocess.Popen('free -m',shell=True,stdout=subprocess.PIPE)
		ret=subp.stdout.readlines()
		mem_dict={}
		mem_dict['total']=ret[1].split()[1]
		mem_dict['used']=ret[1].split()[2]
		mem_sum="%.2f"%(float(mem_dict['used'])/float(mem_dict['total']))
		mem_sum=mem_sum[2:] 
		mem_dict['mem_sum']=mem_sum
		mem_dict['host_id']=self.host_id
		mem_dict['type']='mem'
		ret=json.dumps(mem_dict)
		return ret

