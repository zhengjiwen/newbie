#!/usr/bin/env python
# -*- coding: utf-8 -*-
# Pw @ 2015-12-29 13:18:28
# Description:

id_host='test1'

redis_ip='127.0.0.1'

redis_channel="test"

rabbit_ip='127.0.0.1'

rabbit_channel="test"
