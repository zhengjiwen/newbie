监控报警软件



使用方法
server端：
修改server内conf/setting.py文件
运行 bin/server.py


client端：
修改client内conf/setting.py文件
运行 bin/client.py
