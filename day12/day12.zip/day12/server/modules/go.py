#!/usr/bin/env python
# -*- coding: utf-8 -*-
# Pw @ 2015-12-29 13:04:37
# Description:


from modules import monitor
from conf import setting
import time
import pickle

#主函数
class go(object):
	def __init__(self):

		self.redis=monitor.RedisHelper(setting.redis_ip,setting.redis_channel)
		self.rabbitmq=monitor.Rabbitmq(setting.rabbit_ip,setting.rabbit_channel)

	def send(self):
		monitor_project=pickle.dumps(setting.monitor_project)
		self.redis.public(monitor_project)
	def do_func(self):
		self.rabbitmq.consume()
