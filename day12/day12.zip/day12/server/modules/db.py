#!/usr/bin/env python
# -*- coding: utf-8 -*-
# Pw @ 2015-12-30 07:37:03
# Description:
 
from sqlalchemy import create_engine, Table, Column, Integer, String, MetaData, ForeignKey
from conf import setting

dbd=setting.database
 
metadata = MetaData()
 
host = Table('host', metadata,
    Column('id', Integer, primary_key=True),
    Column('name', String(20)),
)
 
cpu = Table('color', metadata,
    Column('id', Integer, primary_key=True),
    Column('name', String(20)),
)

engine = create_engine(dbd['dbtype']+dbd['engine']+'://'+dbd['user']+dbd['passwd']+'@'+dbd['ip']+':'+dbd['port']+'/'+dbd['name'], max_overflow=5)
 
metadata.create_all(engine)

# metadata.clear()
# metadata.remove()
