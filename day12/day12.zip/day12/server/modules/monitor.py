#!/usr/bin/env python
# -*- coding: utf-8 -*-
# Pw @ 2015-12-29 12:40:04
# Description:
import redis
import pika
from conf import setting
from modules import send
import json

# you know
class RedisHelper:

	def __init__(self,ip,chan):
		self.__conn = redis.Redis(host=ip)
		self.chan_pub = chan

	def public(self, msg):
		self.__conn.publish(self.chan_pub, msg)
		return True

class Rabbitmq:
	
	def __init__(self,ip,chan):
			
		connection = pika.BlockingConnection(pika.ConnectionParameters(host=ip)) 
		self.channel = connection.channel()
		self.chan=chan
		self.channel.queue_declare(queue=self.chan)
		self.mon_dict={}

	def callback(self,ch, method, properties, body):
			
		test_dict=json.loads(body)
		test_dict=json.loads(test_dict)

		#disk监控
		if test_dict['type'] == 'disk':
			if test_dict['host_id']	not in self.mon_dict:
				self.mon_dict[test_dict['host_id']]={'disk':0,'mem':0}
	#{u'use': u'6.4G', u'sum': u'27G', u'free': u'20G', u'pct': u'25%', u'host_id': u'tu'type': u'disk'}
			if int(test_dict['pct']) > setting.disk_threshold:
				num=self.mon_dict[test_dict['host_id']]['disk']
				self.mon_dict[test_dict['host_id']]['disk']=int(num)+1
			else:
				self.mon_dict[test_dict['host_id']]['disk']=0

			if self.mon_dict[test_dict['host_id']]['disk'] > 5:
				if self.mon_dict[test_dict['host_id']]['disk'] < 7:
					send.send_mail(setting.mail,'host_id: %s Hard disk use more than %s'%(test_dict['host_id'],setting.disk_threshold))


		#内存监控
		elif test_dict['type'] == 'mem':
			if test_dict['host_id'] not in self.mon_dict:
				self.mon_dict[test_dict['host_id']]={'disk':0,'mem':0}
			if int(test_dict['mem_sum']) > setting.mem_threshold:
				num=self.mon_dict[test_dict['host_id']]['mem']
				self.mon_dict[test_dict['host_id']]['mem']=int(num)+1
			else:
				self.mon_dict[test_dict['host_id']]['mem']=0

			if self.mon_dict[test_dict['host_id']]['mem'] > 5:
				if self.mon_dict[test_dict['host_id']]['mem'] < 7:
					send.send_mail(setting.mail,'host_id: %s memory use more than %s'%(test_dict['host_id'],setting.mem_threshold))



	def consume(self):
		self.channel.basic_consume(self.callback,queue=self.chan,no_ack=True)
		print('running ...')
		self.channel.start_consuming()
