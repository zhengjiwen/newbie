#!/usr/bin/env python
# -*- coding: utf-8 -*-
# Pw @ 2015-12-29 13:18:28
# Description:

mail='zjw2227680283@qq.com'

redis_ip='127.0.0.1'

redis_channel="test"

rabbit_ip='127.0.0.1'

rabbit_channel="test"

#监控时间间隔
monitor_time=2
#db_type+db_engine+'://'+db_user+db_passwd+'@'+db_ip+':'+db_port+'/'+db_name

#engine = create_engine("mysql+mysqldb://root:123@127.0.0.1:3306/s11", max_overflow=5)

#监控项
monitor_project=['mem','disk']

#阈值
mem_threshold=20

disk_threshold=20

database = {
	'dbtype':'mysql',
	'engine':'mysqldb',
	'user':'root',
	'passwd':'asdasd',
	'ip':'127.0.0.1',
	'port':'3306',
	'name':'test',
	'max_overflow':5, 
			}

