#!/usr/bin/env python
# -*- coding: utf-8 -*-
# Pw @ 2015-11-26 02:37:51
# author: 郑集文

import pickle
with open('eml.txt','r') as ef:
	a=pickle.load(ef)
print a
