﻿day5 atm+购物车+账单
author 郑集文

#需在linux系统下执行
#!!!绑定邮箱时向邮箱发送随机6位验证码。
#邮箱验证：!!!支持邮箱格式验证。
#密码验证：!!!支持非数字判断 密码为空报错。不能超三次错误，输入密码正确后清零，错误超三次后邮箱被锁定。
#商品列表在shangpin.txt
#对账单在duizhangdan目录下。

#atm
1.执行python main.py

#添加商品
1.执行python addshangpin.py

#shop
1.执行python shop.py


！！！账单系统
#加入定时任务
crontab dingshi.txt

dingshi.txt文件内容
* * * 1-12 * python fazhangdan.py #每月账单
* * 28 12 * python addform.py	   #新增次年账单
