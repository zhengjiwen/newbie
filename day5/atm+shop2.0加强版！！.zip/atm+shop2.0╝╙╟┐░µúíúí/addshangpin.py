#!/usr/bin/env python
# -*- coding: utf-8 -*-
# Pw @ 2015-11-16 22:27:51
# author: 郑集文
# Description:

import os
from module import shop

if __name__=='__main__':
	pass

shop.addsp()
