#!/usr/bin/env python
# -*- coding: utf-8 -*-
# Pw @ 2015-11-16 12:49:12
# author: 郑集文
# Description:

import smtplib
from email.mime.text import MIMEText
from email.utils import formataddr

def youjian(dizhi,*args): 

	msg = MIMEText('本月账单:%s'%args, 'plain', 'utf-8')
	msg['From'] = formataddr(["天朝银行",'jzzjw@139.com'])
	msg['To'] = formataddr(["go",dizhi])
	msg['Subject'] = "Form"
	server = smtplib.SMTP("smtp.139.com", 25)
	server.login("jzzjw@139.com", "asdasdasd")
	server.sendmail('jzzjw@139.com', [dizhi,], msg.as_string())
	server.quit()
